# Graphic-LCD-128-64
New Altium library for Graphic LCD 128*64 (GLCD128*64).

It contains schematic and PCB and suitable for famous GLCD drivers such as ST7920 and KS0108.

It also has 3D model for better view. 😎

Enjoy 😉
